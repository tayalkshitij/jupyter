from django.apps import AppConfig


class HowdyConfig(AppConfig):
    name = 'howdy'
