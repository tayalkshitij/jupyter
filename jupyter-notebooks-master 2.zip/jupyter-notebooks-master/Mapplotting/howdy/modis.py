from __future__ import print_function
import glob
import numpy as np
import math
from pyhdf.SD import SD, SDC
#import matplotlib
#matplotlib.use('TkAgg')
#import pylab
#import matplotlib.pyplot as plt
import datetime
import subprocess
from numpy import genfromtxt
#from plotly.offline import download_plotlyjs, init_notebook_mode, plot, iplot
#import plotly.graph_objs as go
from scipy.spatial import cKDTree
import plotly.plotly as py
import plotly.graph_objs as go
import plotly
import bs4
import itertools
import bottleneck as bn
from scipy.signal import lfilter
from itertools import compress
from numpy import inf

#from IPython.display import clear_output

#plotly.offline.init_notebook_mode(connected=True)

LatLongtree = []
NDVISTACK = []
NDVIaverage = []
sorteddates = []
dates = []
#MaxMin = []
#MaxMin_average = []
YearChange = []
YearChange_average = []
Years_datetime = []
latitude = []
longitude = []
CLEANED_DATA = []
LatLong_topk = ''	
latmin = 0
latmax = 0
lonmin = 0
lonmax = 0

def initialize():
	global  NDVISTACK,NDVIaverage, sorteddates, dates, LatLongtree, latitude, longitude, CLEANED_DATA
	latitude = genfromtxt('/home/kumarv/tayal007/LongLatCoordinates/h21v07/latitide.csv', delimiter=',')
	longitude = genfromtxt('/home/kumarv/tayal007/LongLatCoordinates/h21v07/longitude.csv', delimiter=',')
	directorypath = glob.glob("/home/kumarv/tayal007/MODIS_TILES/MODIS_h21v07/*.hdf");
	sorteddates = sortedtimestamp(directorypath)
	for k, v in sorted(sorteddates.items()):
    		dates.append(k);
	temp = []	
	for i in range(2400):
		for j in range(2400):
			tup = latitude[i,j], longitude[i,j]
			temp.append(tup)
	LatLongdata = np.array(temp)
	temp = None # clear memory
	LatLongtree = cKDTree(LatLongdata)
	NDVISTACK = np.load('/home/kumarv/tayal007/MODIS_TILES/h21v07.npy')
	#CLEANED_DATA = np.load('/home/kumarv/tayal007/cleaned_data.npy')
	CLEANED_DATA = cleanNDVI();
	#markercluster(dates)
	markerclusterYearChange(dates)
	initiatelatlong();
	#NDVIaverage = np.load('/home/kumarv/tayal007/NDVIaverage.npy')
	return ""

def initiatelatlong():
	global latmin, latmax, lonmin, lonmax
	latmin = min(latitude[0,0],latitude[2399,2399])
	latmax = max(latitude[0,0],latitude[2399,2399])
	lonmin = min(longitude[0,0],longitude[2399,2399])
	lonmax = max(longitude[0,0],longitude[2399,2399])

def cleanNDVI():
	print ("Missing value in raw data is ", np.count_nonzero(np.isnan(NDVISTACK)),'which is ' ,percentage(np.count_nonzero(np.isnan(NDVISTACK)),NDVISTACK.shape),'%')
	print ("Infinity value in raw data is ", np.count_nonzero(np.isinf(NDVISTACK)),'which is ' ,percentage(np.count_nonzero(np.isinf(NDVISTACK)),NDVISTACK.shape),'%')
	print ("Greater than 1 is ", np.count_nonzero(NDVISTACK > 1),'which is ' ,percentage(np.count_nonzero(NDVISTACK > 1),NDVISTACK.shape),'%')
	print ("Less than -1 is ", np.count_nonzero(NDVISTACK < -1),'which is ' ,percentage(np.count_nonzero(NDVISTACK < -1),NDVISTACK.shape),'%')
	
	CLEANED_DATA = np.copy(NDVISTACK)
	CLEANED_DATA[NDVISTACK == inf] = np.nan
	CLEANED_DATA[NDVISTACK == -inf] = np.nan
	CLEANED_DATA[NDVISTACK > 1] = np.nan
	CLEANED_DATA[NDVISTACK < -1] = np.nan

	print ("After Cleaning Missing value is ", np.count_nonzero(np.isnan(CLEANED_DATA)),'which is ' ,percentage(np.count_nonzero(np.isnan(CLEANED_DATA)),NDVISTACK.shape),'%')
	return CLEANED_DATA;

'''def markercluster(dates):
	global MaxMin, MaxMin_average, Years_datetime
	Years = []
	for x in dates:
		Years.append(x.year)
	UniqueYears = sorted(list(set(Years)))
	MaxMin = np.zeros(shape=(2400,2400,len(UniqueYears)),dtype=np.float32)
	i = 0
	old = 0
	new = 0

	for x in dates:
		if x.year == UniqueYears[i]:
        		new = new + 1
		else:
        		mini = np.nanmin(CLEANED_DATA[:,:,old:new], axis=2)
        		mini[mini < 0] = 0;
        		MaxMin[:,:,i] = (np.nanmax(CLEANED_DATA[:,:,old:new], axis=2) - mini).astype(np.float32);
        		i = i + 1
        		old = new
        		new = new + 1
	mini = np.nanmin(CLEANED_DATA[:,:,old:new], axis=2)
	mini[mini < 0] = 0;
	MaxMin[:,:,i] = (np.nanmax(CLEANED_DATA[:,:,old:new], axis=2) - mini).astype(np.float32);	
	MaxMin_average = np.nanmean(MaxMin, axis=2);
	for x in UniqueYears:
		Years_datetime.append(datetime.datetime.strptime('30/12/' + str(x), '%d/%m/%Y'))
	return "" '''


def markerclusterYearChange(dates):
	global YearChange, YearChange_average, Years_datetime
	Years = []
	for x in dates:
		Years.append(x.year)
	UniqueYears = sorted(list(set(Years)))
	YearChange = np.zeros(shape=(2400,2400,len(UniqueYears)),dtype=np.float32)
	i = 0
	old = 0
	new = 0

	for x in dates:
		if x.year == UniqueYears[i]:
        		new = new + 1
		else:
			mini = CLEANED_DATA[:,:,old:new]
			mini[mini < 0] = 0;
			YearChange[:,:,i] = (np.nanmean(mini, axis=2)).astype(np.float32);
			i = i + 1;
			old = new;
			new = new + 1;
	mini = CLEANED_DATA[:,:,old:new]
	mini[mini < 0] = 0;
	YearChange[:,:,i] = (np.nanmean(mini, axis=2)).astype(np.float32);
	for j in range(len(UniqueYears) - 3):
		YearChange[:,:,j] = np.absolute(YearChange[:,:,(j + 2)] - YearChange[:,:,j+1])
	YearChange[:,:,j+1] = 0
	YearChange[:,:,j+2] = 0
	YearChange[:,:,j+3] = 0
	YearChange_average = np.nanmax(YearChange, axis=2);
	for x in UniqueYears[3:]:
		Years_datetime.append(datetime.datetime.strptime('30/12/' + str(x), '%d/%m/%Y'))
	return "" 

def percentage(part, shape):
    whole = shape[0] * shape[1] * shape[2]
    return 100 * float(part)/float(whole)


def topkLatLong(top_k):
	global LatLong_topk
	LatLong_topk = ''
	idx = top_n_indexes(YearChange_average, top_k)
	idx.sort(key = lambda tup: tup[0])
	for x in idx:
		LatLong_topk = LatLong_topk + "{lat:" + str(latitude[x]) + ', lng: ' + str(longitude[x]) + '},'
		print (x, YearChange_average[x], latitude[x], longitude[x])
	return ""

def getMatrixdimension(latitude, longitude):
	dists, indexed = LatLongtree.query(np.array([latitude,longitude]), k = 1)
	quotient = indexed//2400;
	remainder = indexed%2400;
	print (quotient, remainder, indexed, dists, latitude, longitude)
	return (quotient,remainder) # ( row, column)

def top_n_indexes(arr, n):
	idx = bn.argpartition(arr, arr.size-n, axis=None)[-n:]
	width = arr.shape[1]
	return [divmod(i, width) for i in idx]

def getDigitalglobe(latitude,longitude):

	lat_min = latitude;
	lon_min = longitude;
	lat_pixel_size = 2.7E-6
	lon_pixel_size = 2.7E-6
	ddims = 11
	bbox_str = str(lon_min-ddims*lon_pixel_size*1.0) + ',' + str(lat_min-ddims*lat_pixel_size*1.0) + ',' + str(lon_min+ddims*lon_pixel_size*1.0) + ',' + str(lat_min+ddims*lat_pixel_size*1.0)
	command = "curl --user Gophers:subregional.Varnished.1umbering 'https://services.digitalglobe.com/mapservice/wmsaccess?connectid=df282532-3390-42a8-b682-dab0abaa7b3a&SERVICE=WMS&REQUEST=GetFeatureInfo&version=1.1.1&SRS=EPSG:4326&BBOX=" + bbox_str + "&WIDTH=1000000&HEIGHT=100000&QUERY_LAYERS=DigitalGlobe:ImageryFootprint&X=5&Y=5&LAYERS=DigitalGlobe:ImageryFootprint&FEATURE_COUNT=100000'"
	output = subprocess.check_output(command, shell=True) # os.system(command)
	output = output.splitlines();
	matching = [s for s in output if b'acquisitionDate' in s]
	#print ("No of images", len(matching))
	DGtimestamp = []
	for localimage in matching:
		DGtimestamp.append(localimage.split(b' ')[2].decode("utf-8"));
	timestamps = [datetime.datetime.strptime(ts, "%Y-%m-%d").date() for ts in DGtimestamp]
	DGtimestamp = None
	return timestamps;

def sortedtimestamp(directorypath):
	timestamps = dict()
	for path in directorypath:
            timestamps[datetime.datetime.strptime(path.split('.')[1][3:], '%y%j').date()] = path.split('.')[1]
	return timestamps;


def renderplot():
	plt.imshow(NDVIaverage)
	while True:
    		x = plt.ginput(1)
		#print (NDVISTACK[int(round(x[0][1])),int(round(x[0][0])),:])
    		try:
        		#lat = latitude[int(round(x[0][0]))][int(round(x[0][1]))]
        		#long = longitude[int(round(x[0][0]))][int(round(x[0][1]))]
        		#print ('http://maps.google.com/?q=' + str(lat) + ',' + str(long))
        		showtimeseries(int(round(x[0][0])), int(round(x[0][1])));
    		except IndexError:
        		print ()


def showtimeseries(yvalue, xvalue):  
	counts = NDVISTACK[xvalue,yvalue,:]
	plot([go.Scatter(x=dates, y=counts)])
	#data = [go.Scatter(x=dates, y=counts)]
	#plotly.offline.iplot(data)


def digitalglobeformat(DGtimestamp):
	plottimestamps = []
	for x in DGtimestamp:
		for i in range(3):
			plottimestamps.append(x)
	y = []
	for m in range(len(plottimestamps)):
		y.append(0)
		y.append(1)
		y.append('None')
	return plottimestamps,y

def showtimeseriesLatLong(Lat, Lon , Top_K, croplandurl, ZOOM):
	Lat = float(Lat)
	Lon = float(Lon) 
	Top_K = int(Top_K)
	zoom = int(ZOOM)
	n = 15  # the larger n is, the smoother curve will be
	b = [1.0 / n] * n
	a = 1

	if (croplandurl != ''):
		Lat = float(croplandurl.split('/')[4].split('&')[0].split('=')[-1])
		Lon = float(croplandurl.split('/')[4].split('&')[1].split('=')[1])
		zoom = int(croplandurl.split('/')[4].split('&')[2].split('=')[1])


	if ((latmin <= Lat <= latmax) and (lonmin <= Lon <= lonmax)):
		topkLatLong(Top_K);
		xvalue,yvalue = getMatrixdimension(Lat, Lon)
		DGtimestamp = getDigitalglobe(Lat,Lon)
		plottimestamps,yrange = digitalglobeformat(DGtimestamp)


		iA = ~np.isnan(CLEANED_DATA[xvalue,yvalue,:])
		NonNanList = np.where(iA == True)
		Nandates = list(compress(dates, iA))

		modis_data = go.Scatter(x=Nandates, y=list(itertools.chain.from_iterable(NDVISTACK[xvalue,yvalue,NonNanList])),name='MODIS')
		DG_data = go.Scatter(x=plottimestamps, y=yrange, name = 'Digital Globe')
		
		#MaxMin_data = go.Scatter(x=Years_datetime, y = YearChange[xvalue,yvalue,:], name = "Yearly MaxMin -" + str(YearChange_average[xvalue,yvalue]))
		#filter_data = go.Scatter(x=Nandates, y=list(itertools.chain.from_iterable(CLEANED_DATA[xvalue,yvalue,NonNanList])), name = 'Filtered Data')
		
		#data = [modis_data, DG_data, MaxMin_data, filter_data]
		data = [modis_data, DG_data]
		layout = go.Layout(
    		title = 'NDVI Plot', 
    		width = 1800,
    		height = 900,
    		xaxis=dict(
        	showgrid=True,
        	zeroline=True,
        	showline=True,
        	tickangle=-30,
        	tick0=datetime.datetime.strptime('2000/12/30', '%Y/%m/%d'),
        	dtick= 'M12',
        	mirror='ticks',
        	gridcolor='#000000',
        	gridwidth=1,
        	zerolinecolor='#000000',
        	zerolinewidth=2,
        	linecolor='#000000',
        	linewidth=4,
        	tickwidth=2,
        	tickformat = "%Y",
        	hoverformat = "%d-%b-%Y"
    		),
    		yaxis=dict(
        	showgrid=True,
        	zeroline=True,
        	showline=False,
        	mirror='ticks',
        	gridcolor='#000000',
        	gridwidth=1,
        	zerolinecolor='#000000',
       		zerolinewidth=2,
        	linecolor='#000000',
        	linewidth=4
   		 )
		)
		fig = go.Figure(dict(data=data), layout=layout)
		plotly.offline.plot(fig, filename='/home/kumarv/tayal007/Plots/plotly.html',auto_open=False)		
	else:
		f = open("/home/kumarv/tayal007/Plots/plotly.html",'w')
		message= """<html><head></head<body><h1>NDVI GRAPH</h1><p>You input Latitude = """
		f.write(message)
		f.write(str(Lat))
		f.write(" and Longitude = ")
		f.write(str(Lon))
		message = """ which is currently out of range</p><p>Latitude should be in range 30.002 and 39.998</p><p>Longitide should be in range -130.53 and -103.93</p></body> </html>"""
		f.write(message)
		f.close()
	'''with open("/home/kumarv/tayal007/Plots/plotly.html") as inf:
			txt = inf.read()
			soup = bs4.BeautifulSoup(txt)

	metatag = soup.new_tag('meta')
	metatag.attrs['http-equiv'] = 'refresh'
	metatag.attrs['content'] = '2' # time to refresh
	soup.head.append(metatag)
	# save the file again
	with open("/home/kumarv/tayal007/Plots/plotly.html", "w") as outf:
    		outf.write(str(soup))'''		
	return LatLong_topk, Lat, Lon, zoom;
