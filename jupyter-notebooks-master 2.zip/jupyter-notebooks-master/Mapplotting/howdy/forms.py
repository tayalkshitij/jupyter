class LocationForm(forms.Form):
    latitude = form.CharField()
    longitude = form.CharField()
