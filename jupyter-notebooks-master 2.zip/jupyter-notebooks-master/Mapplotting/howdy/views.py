#howdy/views.py
from django.shortcuts import render
from django.views.generic import TemplateView
import matplotlib.pyplot as plt
import numpy as np
from howdy.abc import *
from howdy.modis import *

#i = 0

# Create your views here.
class HomePageView(TemplateView):
   def get(self, request, **kwargs):
      initialize()
      print("Initialization Done 1")
      return render(request, 'index.html', context=None)


def submit(request):
   LAT=request.POST['Latbox']
   LON= request.POST['Lonbox']
   ZOOM= request.POST['zoom']
   Top_K= request.POST['topk']
   croplandurl = request.POST['Cropland']
   #LatLong_topk = showtimeseriesLatLong(LAT, LON, Top_K)
   LatLong_topk, LAT, LON, ZOOM = showtimeseriesLatLong(LAT, LON, Top_K, croplandurl, ZOOM)
   createHTML(LAT, LON, ZOOM, LatLong_topk ) 
   return render(request,'index.html',context=None)


# class HomePageView(TemplateView):
#     def get(self, request, **kwargs):
#         form = LocationForm()
#         return render(request, 'index.html', {"form": form})
  

# def post(self, request, **kwargs):
#         form = LocationForm(request.POST)
#         if form.is_valid():
#             pass  # do something with form.cleaned_data
#         return render(request, 'index.html', {"form": form})
